describe('LoginCtrl',function(){
    beforeEach(module('ShareITFacbuk'));
    var $controller;
    beforeEach(inject(function(_$controller_){
        $controller = _$controller_;
    }));
    
    describe('LoginCtrl',function(){
        it('Tests username  is empty',function(){
            var $scope={};
            var controller = $controller('LoginCtrl',{$scope:$scope});
            var username;
            expect($scope.username(username)).toEqual('vani_****@yahoo.in'); // success
            expect($scope.username(username)).toEqual('vani'); //fails
        });
    });
});
describe('profileCtrl',function(){
    beforeEach(module('ShareITFacbuk'));
    var $controller;
    beforeEach(inject(function(_$controller_){
        $controller = _$controller_;
    }));